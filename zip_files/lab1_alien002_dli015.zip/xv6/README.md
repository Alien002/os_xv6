# os_xv6
CS 153 - Operating Systems <br />
Team: Alic Lien, Daniel Li <br />
Project: Modified XV6 <br />
Last edited: 1/24/2019 - 13:30 <br />



## Summary
Modified XV6 Program for calss <br />

## Usage
To be honest I'm not sure right now <br />


## External Libraries
I'll let you know if I use any <br />


## Notes for files
-- void exit(int status) edits --<br />
- User.h <br />
    - echo.c <br />
    - forktest.c <br />
    - grep.c <br />
    - init.c <br />
    - kill.c <br />
    - ln.c <br />
    - ls.c <br />
    - mkdir.c <br />
    - rm.c <br />
    - sh.c <br />
    - stressfs.c <br />
    - wc.c <br />
    - zombie.c <br />
    - **Usertests.c <br />


-- int wait(void) into int wait(int *status) -- <br />
- User.h <br />
    - defs.h <br />
    - forktest.c <br /> 
    - init.c <br />
    - proc.c <br />
    - sh.c <br />
    - stressfc.c <br />
    - user.h <br />
    - usertests.c <br />




-- lab1 2 --<br />
- c: 18, exit: 22   <br />
- c: 19, exit: 23   <br />
- c: 17, exit: 21  **   <br />
- c: 20, exit: 24  **   <br />
- c: 21, exit: 25   <br />


